﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Answer;
namespace Answer
{
    public class Answer
    {
        char answerID;
        string answerDescr;

        //the method name says it function
        public Answer()
        {
            answerID = ' ';
            answerDescr = "";
        }

        //polymorphism done below
        public Answer(char answerID, string answerDescr)
        {
            this.answerID = answerID;
            this.answerDescr = answerDescr;
        }
        //the method name says it function
        public string getAnswer()
        {

            return answerDescr;
        }
        //the method name says it function
        public char getAnswerID()
        {
            return answerID;
        }
        //the method name says it function
        public void setAnswerID(char answerID)
        {
            this.answerID = answerID;
        }
    }
}
