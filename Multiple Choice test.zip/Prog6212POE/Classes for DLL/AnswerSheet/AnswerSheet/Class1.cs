﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Answer;
using Question;
using Test;
namespace AnswerSheet
{
    public class AnswerSheet
    {
        Test.Test testTaken;
        //Student student;
        List<char> answers;
        private int totalMarks;
        private int actualMarks;
        private int testAttempt;

        public AnswerSheet()
        {
            testTaken = new Test.Test();
            answers = new List<char>();
            testAttempt = 0;
        }
        public AnswerSheet(Test.Test test)
        {
            testTaken = test;
            answers = new List<char>();
            for (int i = 0; i < testTaken.getQuestionCount(); i++)
            {
                answers.Add(' ');
            }
        }
        //the method name says it function
        public int getTestAttempt() {
            return testAttempt;
        }
        //the method name says it function
        public void setTestAttempt(int testAttempt) {
            this.testAttempt = testAttempt;
        }
        //the method name says it function
        public string getTestName() {
            return testTaken.getTestName();
        }
        //the method name says it function
        public void setTotalMarks(int totalMarks)
        {
            this.totalMarks = totalMarks;
        }
        //the method name says it function
        public int getTotalMarks()
        {
            return totalMarks;
        }
        //the method name says it function
        public void setActualMarks(int actualMarks)
        {
            this.actualMarks = actualMarks;
        }
        //the method name says it function
        public int getActualMarks()
        {
            return actualMarks;
        }
        //the method name says it function
        public List<Question.Question> GetQuestions()
        {

            return testTaken.getQuestions();
        }
        //the method name says it function
        public void setAnswer(int ID, char answer)
        {
            answers[ID] = answer;

        }
        //the method name says it function
        public char getAnswer(int ID)
        {
            return answers[ID];
        }
    }
}
