﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Answer;
namespace Question
{
    public class Question
    {
        int questionNumber;
        string actualQuestion;
        char correctAnswer;
        List<Answer.Answer> answers;
        List<Answer.Answer> shuffledAnswers;
        char shuffledCorrectAnswer;
        
        public Question()
        {
            questionNumber = 0;
            actualQuestion = "";
            correctAnswer = ' ';
            answers = new List<Answer.Answer>();
        }
        //method for question which will be the question number and the actual question
        public Question(int questionNumber, string actualQuestion)
        {
            this.questionNumber = questionNumber;
            this.actualQuestion = actualQuestion;

            correctAnswer = ' ';
            answers = new List<Answer.Answer>();
        }

        //list of shuffled answers
        public List<Answer.Answer> getshuffledAnswers()
        {
            return shuffledAnswers;
        }


        // this method is pretty cool it shuffles the answers of the multiple choice question so that no test look alike so cheating will be eliminated
        public void shuffleAnswers()
        {
            Random r = new Random();
            shuffledAnswers = new List<Answer.Answer>();
            foreach (Answer.Answer answer in answers)
            {
                shuffledAnswers.Add(answer);
            }

            int n = shuffledAnswers.Count;
            while (n > 1)
            {
                n--;
                int k = r.Next(n + 1);
                Answer.Answer temp = shuffledAnswers[k];
                shuffledAnswers[k] = shuffledAnswers[n];
                shuffledAnswers[n] = temp;
            }
            char currentAnswer = 'A';
            foreach (Answer.Answer answer in shuffledAnswers)
            {
                if (answer.getAnswerID().Equals('A'))
                {
                    shuffledCorrectAnswer = currentAnswer;
                }
                answer.setAnswerID(currentAnswer);
                currentAnswer += (char)1;
            }


        }

        //this methdo sets the requirements for the question
        public Question(int questionNumber, string actualQuestion, char correctAnswer, List<Answer.Answer> answers)
        {
            this.questionNumber = questionNumber;
            this.actualQuestion = actualQuestion;

            this.correctAnswer = correctAnswer;
            this.answers = answers;
        }
        //the method name says it function
        public string getActualQuestion()
        {
            return actualQuestion;
        }
            //the method name says it function
        public void setCorrectAnswer(char correctAnswer)
        {
            this.correctAnswer = correctAnswer;
        }
        //the method name says it function
        public char getCorrectAnswer()
        {

            return shuffledCorrectAnswer;
        }
        //the method name says it function
        public void addAnswer(Answer.Answer answer)
        {
            this.answers.Add(answer);
        }
    }
}
