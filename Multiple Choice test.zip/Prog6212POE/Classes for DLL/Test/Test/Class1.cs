﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Question;
namespace Test
{
    public class Test
    {
        int testID;
        string testName;
        List<Question.Question> questions;


        // this method sets the test id to 0 and name to blank 
        public Test()
        {
            testID = 0;
            testName = "";
            questions = new List<Question.Question>();
        }
        public List<Question.Question> getQuestions()
        {
            return questions;
        }
        //the method name says it function
        public int getTestID()
        {
            return testID;
        }
        //the method name says it function
        public int getQuestionCount()
        {
            return questions.Count;
        }
        //the method name says it function
        public Question.Question getQuestion(int id)
        {
            return questions[id];
        }

        public Test(int testID, string testName)
        {
            this.testID = testID;
            this.testName = testName;
            questions = new List<Question.Question>();
        }
      
        public Test(int testID, string testName, List<Question.Question> questions)
        {
            this.testID = testID;
            this.testName = testName;
            this.questions = questions;
        }
        //the method name says it function
        public void addQuestion(Question.Question question)
        {
            this.questions.Add(question);
        }
        //the method name says it function
        public string getTestName()
        {
            return testName;
        }
    }
}
