﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Answer;
using Question;
using AnswerSheet;
using Test;
namespace User
{
    public abstract class User
    {
        /*
         * this is the user class 
         * it contains all the neccessary functions that the main program will incorporate 
         * the user class also makes use of polymorphism with the student and lecturer sub-classes
         */
        protected string firstName;
        protected string surname;

        public User(string firstName = "", string surname = "")
        {
            this.firstName = firstName;
            this.surname = surname;
        }

        public string getFirstName()
        {
            return firstName;
        }
        public string getSurname()
        {
            return surname;
        }
        public abstract bool validateUser(string user, string password);
        public abstract int getUserRole();

        public abstract User GetUser();
    }


    //polymorphism is present here 
    public class Lecturer : User
    {
        protected string username;
        protected string password;
        protected List<Test.Test> tests;

        public Lecturer(string firstname, string surname, string username, string password) : base(firstname, surname)
        {
            this.username = username;
            this.password = password;
            this.tests = new List<Test.Test>();
        }


        //this method holds all the neccessary code to validate a user by checking the users 
        //entered text and compares it to the user it saved when the userregister
        public override bool validateUser(string username, string password)
        {
            if (this.username == username && this.password == password)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        //checks if the user is a lecturer or a student
        public override int getUserRole()
        {
            return 1;
        }

        public override User GetUser()
        {
            return this;
        }

        public int getTestCount()
        {
            return tests.Count;
        }

        public void addTest(Test.Test test)
        {
            tests.Add(test);
        }

        //saves a list of test
        public List<Test.Test> GetTests()
        {
            return tests;
        }

    }
    //polymorphism is present here 
    public class Student : User
    {
        protected string studentID;
        protected string password;
        protected List<AnswerSheet.AnswerSheet> answerSheets;

        public Student(string firstname, string surname, string studentID, string password) : base(firstname, surname)
        {
            this.answerSheets = new List<AnswerSheet.AnswerSheet>();
            this.studentID = studentID;
            this.password = password;
        }

        //checks if the user matches the entered credentials
        public override bool validateUser(string studentID, string password)
        {
            if (this.studentID == studentID && this.password == password)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        // the name says its function 
        public String getStudentID()
        {
            return studentID;
        }

        public AnswerSheet.AnswerSheet GetAnswerSheet(int sheet)
        {
            return answerSheets[sheet];
        }

        public int AnswerSheetCount() {
            return answerSheets.Count;
        }

        public override int getUserRole()
        {
            return 0;
        }
        public override User GetUser()
        {
            return this;
        }

        public void addTestAttempt(AnswerSheet.AnswerSheet answerSheet)
        {
            answerSheets.Add(answerSheet);
        }
    }
}
