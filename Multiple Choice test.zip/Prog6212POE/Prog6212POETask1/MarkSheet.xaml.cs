﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using User;
using Test;
using Question;
using Answer;
using AnswerSheet;
namespace Prog6212POETask1
{
    /// <summary>
    /// Interaction logic for MarkSheet.xaml
    /// </summary>
    public partial class MarkSheet : Window
    {
        public List<AnswerSheet.AnswerSheet> answerSheets;
        public StudentScreen window;
        private List<int> Marks;

        public MarkSheet()
        {
            InitializeComponent();
        }
        //simple method to close the mark sheet and take the user back to the previous screen
        private void BtnClose_Click(object sender, RoutedEventArgs e)
        {
            window.Show();
            this.Close();            
        }
        /*
         * this method is used when the window is loaded
         * this method will populate the listbox with the test name.
         */
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            lstTests.Items.Clear();
            txtShowMarks.Text = "";
    
            foreach (AnswerSheet.AnswerSheet answerSheet in answerSheets)
            {
                lstTests.Items.Add(answerSheet.getTestName() + " - Attempt " + answerSheet.getTestAttempt());
            }
        }
        /*
         * this method is used for when the user double clicks on
         * the test name it will take the student to the memorandum of the test selected
         */
        private void LstTests_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            int selection = lstTests.SelectedIndex;
            if (selection == -1)
            {
                return;
            }
            AnswerSheet.AnswerSheet tempSheet = answerSheets[selection];
            MemorandumScreen memoscreen = new MemorandumScreen();
            memoscreen.answersheet = tempSheet;
            memoscreen.hasBeenPushed = true;
            memoscreen.window_mark = this;
            memoscreen.loadTest();
            this.Hide();
            memoscreen.Show();
        }
        /*
         * this method is used for when the user selects the test it will display the marks for the test and the attempts
         */
        private void LstTests_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            Marks = new List<int>();

            txtShowMarks.Text = "";
            int selection = lstTests.SelectedIndex;
            if (selection == -1)
            {
                return;
            }
            AnswerSheet.AnswerSheet answerSheet = answerSheets[selection];
            Marks.Add(answerSheet.getActualMarks());
            txtShowMarks.Text = txtShowMarks.Text + "Test Name \tMark \tPercentage\n";
           // txtShowMarks.Text = txtShowMarks.Text + "=========================\n";
            txtShowMarks.Text = txtShowMarks.Text + "------------------------------------------\n";
            txtShowMarks.Text = txtShowMarks.Text + answerSheet.getTestName() + "\t\t" + answerSheet.getActualMarks() + "/" + answerSheet.getTotalMarks() + "\t" + (Math.Round(((float)answerSheet.getActualMarks() / (float)answerSheet.getTotalMarks() * 100), 2)) + "%\n";


        }
    }
}
