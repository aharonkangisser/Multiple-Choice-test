﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using User;
using Test;
using Question;
using Answer;
using AnswerSheet;
namespace Prog6212POETask1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public List<User.User> Users = new List<User.User>();

        public MainWindow()
        {
            InitializeComponent();
        }

        private void BtnCancel_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        /*
         * this method's function is to take what the user has entered as credentials 
         * and check whether or not they are a user and then verifies the user
         * which will then give them access to the rest of the test app
         */
        private void BtnLogin_Click(object sender, RoutedEventArgs e)
        {
            //check class library for comments about this function
            User.User user = verifyUser();
            
            if (user != null)
            {
                if (user.getUserRole() == 1)
                {
                    Screen2 screen = new Screen2();
                    screen.user = (Lecturer)user;
                    screen.window = this;
                    screen.Show();
                    this.Hide();
                    txtUsername.Text = "";
                    txtPassword.Text = "";
                }
                else
                {
                    StudentScreen s2 = new StudentScreen();
                    s2.user = (Student)user;
                    s2.window = this;
                    s2.Show();
                    this.Hide();
                    txtUsername.Text = "";
                    txtPassword.Text = "";

                }
            }
            else
            {
                MessageBox.Show("Incorrect username or password");
              
            }
        }

        //this verifies if the user has entered the correct credentials
        private User.User verifyUser()
        {
            User.User tempUser = null;
            string username = txtUsername.Text;
            string password = txtPassword.Text;

            // bool verified = false;

            foreach (User.User user in Users)
            {
                if (user.validateUser(username, password))
                {
                    tempUser = user;
                    break;
                }
            }

            return tempUser;
        }
        // this opens the registration screen
        private void BtnRegister_Click(object sender, RoutedEventArgs e)
        {
            RegistrationScreen rs = new RegistrationScreen();
            rs.window = this;
            rs.Show();
            this.Hide();
            
            txtUsername.Text = "";
            txtPassword.Text = "";
        }


        /*
         * this method is used to pre-populate the app with test data for debugging purposes
         */
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
           
            //unit test for test
            List<Question.Question> questions = new List<Question.Question>();

            List<Answer.Answer> answers = new List<Answer.Answer>();
            Answer.Answer answer = new Answer.Answer('A', "Correct Answer A");
            answers.Add(answer);
            answer = new Answer.Answer('B', "Incorrect Answer B");
            answers.Add(answer);
            answer = new Answer.Answer('C', "Incorrect Answer C");
            answers.Add(answer);
            Question.Question question = new Question.Question(1, "Question 1", 'A', answers);
            questions.Add(question);

            answers = new List<Answer.Answer>();
            answer = new Answer.Answer('A', "Correct Answer A");
            answers.Add(answer);
            answer = new Answer.Answer('B', "Incorrect Answer B");
            answers.Add(answer);
            question = new Question.Question(2, "Question 2", 'A', answers);
            questions.Add(question);

            answers = new List<Answer.Answer>();
            answer = new Answer.Answer('A', "Correct Answer A");
            answers.Add(answer);
            answer = new Answer.Answer('B', "Incorrect Answer B");
            answers.Add(answer);
            answer = new Answer.Answer('C', "Incorrect Answer C");
            answers.Add(answer);
            answer = new Answer.Answer('D', "Incorrect Answer D");
            answers.Add(answer);
            answer = new Answer.Answer('E', "Incorrect Answer E");
            answers.Add(answer);
            question = new Question.Question(3, "Question 3", 'A', answers);
            questions.Add(question);

            Test.Test test = new Test.Test(1, "Test 1", questions);

            //unit test for lecturer
            User.Lecturer lecturer = new Lecturer("Bruce", "Simon", "a", "a");
            lecturer.addTest(test);

            Users.Add(lecturer);
            //unit test for Student
            User.User student = new Student("Polly", "Blank", "b", "b");
            Users.Add(student);
        }
    }
}
