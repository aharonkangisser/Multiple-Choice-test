﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using User;
using Test;
using Question;
using Answer;
using AnswerSheet;
namespace Prog6212POETask1
{
    /// <summary>
    /// Interaction logic for StudentScreen.xaml
    /// </summary>
    public partial class StudentScreen : Window
    {
        public Student user;
        public MainWindow window;
        private AnswerSheet.AnswerSheet answersheet;
       // private MemorandumScreen memoScreen;
        private List<Test.Test> tests;
        public StudentScreen()
        {
            InitializeComponent();
        }

        //simple set method
        public void setAnswerSheet(AnswerSheet.AnswerSheet answersheet)
        {
            this.answersheet = answersheet;
        }


        /*
         * this method hold the memorandum for the test and saves it according to the answersheet
         * also adds the attempt 
         */
        public void pushMemorandum()
        {
            MemorandumScreen memoscreen = new MemorandumScreen();
            int count = 1;
            for (int i = 0; i < user.AnswerSheetCount(); i++)
            {
                if (user.GetAnswerSheet(i).getTestName() == answersheet.getTestName())
                {
                    count++;
                }
            }
            answersheet.setTestAttempt(count);
            memoscreen.answersheet = answersheet;
            memoscreen.hasBeenPushed = false;
            memoscreen.window = this;
            memoscreen.loadTest();
            this.Hide();
            memoscreen.Show();
        }

        //signs the student out of the home screen and takes them to the login screen
        private void BtnSignOut_Click(object sender, RoutedEventArgs e)
        {
            window.Show();
            this.Close();
        }

        /*
         * this method used for the view memo button 
         * this will take the user to the memo of the test selected 
         * if the user has not yet taken the test the user will receive a message saying please take the test first
         * this will also display for multiple attempts taken it will show the most recent attempt
         */
        private void BtnViewMemo_Click(object sender, RoutedEventArgs e)
        {
            //pushMemorandum();
            AnswerSheet.AnswerSheet tempSheet = new AnswerSheet.AnswerSheet();
            int selection = lstViewTestStudent.SelectedIndex;
            if (selection == -1)
            {
                return;
            }

            int currentCount = -1;

            for (int i = 0; i < user.AnswerSheetCount(); i++)
            {
                if (user.GetAnswerSheet(i).getTestName() == tests[selection].getTestName())
                {
                    if (user.GetAnswerSheet(i).getTestAttempt() > currentCount)
                    {
                        tempSheet = user.GetAnswerSheet(i);
                        currentCount = tempSheet.getTestAttempt();
                    }
                    
                }
            }

            if (currentCount == -1)
            {
                MessageBox.Show("Please take the test before viewing the memorandum");
            }
            else
            {
                MemorandumScreen memoscreen = new MemorandumScreen();
                memoscreen.answersheet = tempSheet;
                memoscreen.hasBeenPushed = true;
                memoscreen.studentView = true;
                memoscreen.window = this;
                memoscreen.loadTest();
                this.Hide();
                memoscreen.Show();
            }

        }

        /*
         * this method populates the list box when the window loads up 
         * and will diplay the test that are available for the student
         */
        private void Window_Activated(object sender, EventArgs e)
        {
            tests = new List<Test.Test>();
            lstViewTestStudent.Items.Clear();
            foreach (User.User user in window.Users)
            {
                if (user.getUserRole() == 1)
                {
                    Lecturer lecturer = (Lecturer)user;
                    List<Test.Test> temptests = lecturer.GetTests();
                    foreach (Test.Test test in temptests)
                    {
                        tests.Add(test);
                        lstViewTestStudent.Items.Add(test.getTestName());
                    }
                }
            }

        }

        /*
         * this method will take the user the test that they have selected and want to take
         * it also checks if the user has selected a test or they will receive a message saying select a test
         */
        private void BtnTakeTest_Click(object sender, RoutedEventArgs e)
        {
            if (lstViewTestStudent.SelectedIndex == -1)
            {
                MessageBox.Show("Please select a test to take");
            }
            else
            {
                int choice = lstViewTestStudent.SelectedIndex;
                Test.Test testTake = tests[choice];
                TestScreen testScreen = new TestScreen();
                testScreen.test = testTake;
                testScreen.studentScreen = this;
                testScreen.Show();
                this.Hide();
            }
        }

        /*
         * this method is used for the student to see their marks 
         */
        private void BtnViewMarks_Click(object sender, RoutedEventArgs e)
        {
            MarkSheet ms = new MarkSheet();
            ms.window = this;
            List<AnswerSheet.AnswerSheet> answerSheets = new List<AnswerSheet.AnswerSheet>();

            for (int i = 0; i < user.AnswerSheetCount(); i++)
            {
                answerSheets.Add(user.GetAnswerSheet(i)); 
            }
            ms.answerSheets = answerSheets;
            ms.Show();
            this.Hide();
        }
    }
}
