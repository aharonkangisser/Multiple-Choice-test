﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using User;
using Test;
using Question;
using Answer;
using AnswerSheet;
namespace Prog6212POETask1
{
    /// <summary>
    /// Interaction logic for TestScreen.xaml
    /// </summary>
    public partial class TestScreen : Window
    {
        public Test.Test test;
        public StudentScreen studentScreen;
        private List<Question.Question> testQuestions;
        private AnswerSheet.AnswerSheet answerSheet;
        private int currentQuestion;
        private int questionCount;
        public TestScreen()
        {
            InitializeComponent();

        }
        private void questionAnswered(int focusQuestion) {
            lstQuestionList.Items.RemoveAt(focusQuestion);
            lstQuestionList.Items.Insert(focusQuestion, "QUESTION" + (focusQuestion + 1) + " - Answered");
            lstQuestionList.SelectedIndex = focusQuestion;

        }

        private void configureAnswer(int focusQuestionIndex)
        {
            switch (answerSheet.getAnswer(focusQuestionIndex))
            {
                case 'A':
                    rdoOptionA.IsChecked = true;
                    break;
                case 'B':
                    rdoOptionB.IsChecked = true;
                    break;
                case 'C':
                    rdoOptionC.IsChecked = true;
                    break;
                case 'D':
                    rdoOptionD.IsChecked = true;
                    break;
                case 'E':
                    rdoOptionE.IsChecked = true;
                    break;
                
            }
        }
        /*
        * this method is used when navigating the test between each question (setting the focus)
        * the way this works is with the switch statement it will show or hide the radio buttons that match the ammount of options 
        */
        private void setQuestionFocus(int focusQuestionIndex)
        {
            Question.Question focusQuestion = testQuestions[focusQuestionIndex];
            List<Answer.Answer> questionAnswers = focusQuestion.getshuffledAnswers();
            txtQuestion.Text = focusQuestion.getActualQuestion();
            int answerCount = questionAnswers.Count;
            questionCount = testQuestions.Count();
            lstQuestionList.SelectedIndex = focusQuestionIndex;
            switch (answerCount)
            {
                case 1:
                    //Enable active answers
                    lblOptionA.Visibility = Visibility.Visible;
                    rdoOptionA.Visibility = Visibility.Visible;
                    rdoOptionA.IsChecked = false;
                    txtOptionA.Visibility = Visibility.Visible;
                    txtOptionA.Text = questionAnswers[0].getAnswer();
                    //Disable inactive answers

                    lblOptionB.Visibility = Visibility.Hidden;
                    rdoOptionB.Visibility = Visibility.Hidden;
                    rdoOptionB.IsChecked = false;
                    txtOptionB.Visibility = Visibility.Hidden;

                    lblOptionC.Visibility = Visibility.Hidden;
                    rdoOptionC.Visibility = Visibility.Hidden;
                    rdoOptionC.IsChecked = false;
                    txtOptionC.Visibility = Visibility.Hidden;

                    lblOptionD.Visibility = Visibility.Hidden;
                    rdoOptionD.Visibility = Visibility.Hidden;
                    rdoOptionD.IsChecked = false;
                    txtOptionD.Visibility = Visibility.Hidden;

                    lblOptionE.Visibility = Visibility.Hidden;
                    rdoOptionE.Visibility = Visibility.Hidden;
                    rdoOptionE.IsChecked = false;
                    txtOptionE.Visibility = Visibility.Hidden;

                    break;
                case 2:
                    //Enable active answers
                    lblOptionA.Visibility = Visibility.Visible;
                    rdoOptionA.Visibility = Visibility.Visible;
                    rdoOptionA.IsChecked = false;
                    txtOptionA.Visibility = Visibility.Visible;
                    txtOptionA.Text = questionAnswers[0].getAnswer();


                    lblOptionB.Visibility = Visibility.Visible;
                    rdoOptionB.Visibility = Visibility.Visible;
                    rdoOptionB.IsChecked = false;
                    txtOptionB.Visibility = Visibility.Visible;
                    txtOptionB.Text = questionAnswers[1].getAnswer();
                    //Disable inactive answers


                    lblOptionC.Visibility = Visibility.Hidden;
                    rdoOptionC.Visibility = Visibility.Hidden;
                    rdoOptionC.IsChecked = false;
                    txtOptionC.Visibility = Visibility.Hidden;

                    lblOptionD.Visibility = Visibility.Hidden;
                    rdoOptionD.Visibility = Visibility.Hidden;
                    rdoOptionD.IsChecked = false;
                    txtOptionD.Visibility = Visibility.Hidden;

                    lblOptionE.Visibility = Visibility.Hidden;
                    rdoOptionE.Visibility = Visibility.Hidden;
                    rdoOptionE.IsChecked = false;
                    txtOptionE.Visibility = Visibility.Hidden;
                    break;
                case 3:
                    //Enable active answers
                    lblOptionA.Visibility = Visibility.Visible;
                    rdoOptionA.Visibility = Visibility.Visible;
                    rdoOptionA.IsChecked = false;
                    txtOptionA.Visibility = Visibility.Visible;
                    txtOptionA.Text = questionAnswers[0].getAnswer();


                    lblOptionB.Visibility = Visibility.Visible;
                    rdoOptionB.Visibility = Visibility.Visible;
                    rdoOptionB.IsChecked = false;
                    txtOptionB.Visibility = Visibility.Visible;
                    txtOptionB.Text = questionAnswers[1].getAnswer();

                    lblOptionC.Visibility = Visibility.Visible;
                    rdoOptionC.Visibility = Visibility.Visible;
                    rdoOptionC.IsChecked = false;
                    txtOptionC.Visibility = Visibility.Visible;
                    txtOptionC.Text = questionAnswers[2].getAnswer();
                    //Disable inactive answers




                    lblOptionD.Visibility = Visibility.Hidden;
                    rdoOptionD.Visibility = Visibility.Hidden;
                    rdoOptionD.IsChecked = false;
                    txtOptionD.Visibility = Visibility.Hidden;

                    lblOptionE.Visibility = Visibility.Hidden;
                    rdoOptionE.Visibility = Visibility.Hidden;
                    rdoOptionE.IsChecked = false;
                    txtOptionE.Visibility = Visibility.Hidden;
                    break;
                case 4:
                    //Enable active answers
                    lblOptionA.Visibility = Visibility.Visible;
                    rdoOptionA.Visibility = Visibility.Visible;
                    rdoOptionA.IsChecked = false;
                    txtOptionA.Visibility = Visibility.Visible;
                    txtOptionA.Text = questionAnswers[0].getAnswer();


                    lblOptionB.Visibility = Visibility.Visible;
                    rdoOptionB.Visibility = Visibility.Visible;
                    rdoOptionB.IsChecked = false;
                    txtOptionB.Visibility = Visibility.Visible;
                    txtOptionB.Text = questionAnswers[1].getAnswer();

                    lblOptionC.Visibility = Visibility.Visible;
                    rdoOptionC.Visibility = Visibility.Visible;
                    rdoOptionC.IsChecked = false;
                    txtOptionC.Visibility = Visibility.Visible;
                    txtOptionC.Text = questionAnswers[2].getAnswer();

                    lblOptionD.Visibility = Visibility.Visible;
                    rdoOptionD.Visibility = Visibility.Visible;
                    rdoOptionD.IsChecked = false;
                    txtOptionD.Visibility = Visibility.Visible;
                    txtOptionD.Text = questionAnswers[3].getAnswer();
                    //Disable inactive answers

                    lblOptionE.Visibility = Visibility.Hidden;
                    rdoOptionE.Visibility = Visibility.Hidden;
                    rdoOptionE.IsChecked = false;
                    txtOptionE.Visibility = Visibility.Hidden;
                    break;
                case 5:
                    //Enable active answers
                    lblOptionA.Visibility = Visibility.Visible;
                    rdoOptionA.Visibility = Visibility.Visible;
                    rdoOptionA.IsChecked = false;
                    txtOptionA.Visibility = Visibility.Visible;
                    txtOptionA.Text = questionAnswers[0].getAnswer();


                    lblOptionB.Visibility = Visibility.Visible;
                    rdoOptionB.Visibility = Visibility.Visible;
                    rdoOptionB.IsChecked = false;
                    txtOptionB.Visibility = Visibility.Visible;
                    txtOptionB.Text = questionAnswers[1].getAnswer();

                    lblOptionC.Visibility = Visibility.Visible;
                    rdoOptionC.Visibility = Visibility.Visible;
                    rdoOptionC.IsChecked = false;
                    txtOptionC.Visibility = Visibility.Visible;
                    txtOptionC.Text = questionAnswers[2].getAnswer();

                    lblOptionD.Visibility = Visibility.Visible;
                    rdoOptionD.Visibility = Visibility.Visible;
                    rdoOptionD.IsChecked = false;
                    txtOptionD.Visibility = Visibility.Visible;
                    txtOptionD.Text = questionAnswers[3].getAnswer();

                    lblOptionE.Visibility = Visibility.Visible;
                    rdoOptionE.Visibility = Visibility.Visible;
                    rdoOptionE.IsChecked = false;
                    txtOptionE.Visibility = Visibility.Visible;
                    txtOptionE.Text = questionAnswers[4].getAnswer();
                    
                    break;                
            }

        }
        
        /*
         * this method is used when the window is loaded 
         * it will display the question name and shuffle the answers so the correct answer wont be in the same spot
         */
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            lblHeadingTest.Content = lblHeadingTest.Content + test.getTestName();

            lstQuestionList.Items.Clear();            
            int count = 0;
            testQuestions = new List<Question.Question>();
            foreach (Question.Question question in test.getQuestions())
            {
                testQuestions.Add(question);
                testQuestions[count].shuffleAnswers();
                lstQuestionList.Items.Add("QUESTION " + (count+1));
                count++;
            }
            answerSheet = new AnswerSheet.AnswerSheet(new Test.Test(test.getTestID(), test.getTestName(), testQuestions));
            
            currentQuestion = 0;
            setQuestionFocus(currentQuestion);
            btnPrevious.Visibility = Visibility.Hidden;
        }
        /*
         * navigation control between each question
         */
        private void BtnNext_Click(object sender, RoutedEventArgs e)
        {            
            currentQuestion++;
            setQuestionFocus(currentQuestion);
            configureAnswer(currentQuestion);
            if (currentQuestion == (questionCount-1))
            {
                btnNext.Visibility = Visibility.Hidden;
            }
            btnPrevious.Visibility = Visibility.Visible;
        }
        /*
         * navigation control between each question
         */
        private void BtnPrevious_Click(object sender, RoutedEventArgs e)
        {
            currentQuestion--;
            setQuestionFocus(currentQuestion);
            configureAnswer(currentQuestion);
            if (currentQuestion == 0)
            {
                btnPrevious.Visibility = Visibility.Hidden;
            }
            btnNext.Visibility = Visibility.Visible;
        }
        /*
         * this sets the the option checked to the current answer selected
         */
        private void RdoOptionA_Checked(object sender, RoutedEventArgs e)
        {
            answerSheet.setAnswer(currentQuestion, 'A');
            questionAnswered(currentQuestion);
        }
        /*
         * this sets the the option checked to the current answer selected
         */
        private void RdoOptionB_Checked(object sender, RoutedEventArgs e)
        {
            answerSheet.setAnswer(currentQuestion, 'B');
            questionAnswered(currentQuestion);
        }
        /*
         * this sets the the option checked to the current answer selected
         */
        private void RdoOptionC_Checked(object sender, RoutedEventArgs e)
        {
            answerSheet.setAnswer(currentQuestion, 'C');
            questionAnswered(currentQuestion);
        }
        /*
         * this sets the the option checked to the current answer selected
         */
        private void RdoOptionD_Checked(object sender, RoutedEventArgs e)
        {
            answerSheet.setAnswer(currentQuestion, 'D');
            questionAnswered(currentQuestion);
        }
        /*
         * this sets the the option checked to the current answer selected
         */
        private void RdoOptionE_Checked(object sender, RoutedEventArgs e)
        {
            answerSheet.setAnswer(currentQuestion, 'E');
            questionAnswered(currentQuestion);
        }
        /*
         * this will display the question that the user selected
         */
        private void LstQuestionList_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            int index = lstQuestionList.SelectedIndex;
            if (index == -1)
            {
                return;
            }
            if (index == currentQuestion)
            {
                return;
            }
            currentQuestion = index;
            setQuestionFocus(currentQuestion);
            configureAnswer(currentQuestion);
            if (currentQuestion == (questionCount-1))
            {
                btnNext.Visibility = Visibility.Hidden;
            }
            else
            {
                btnNext.Visibility = Visibility.Visible;
            }
            if (currentQuestion == 0)
            {
                btnPrevious.Visibility = Visibility.Hidden;
            }
            else
            {
                btnPrevious.Visibility = Visibility.Visible;
            }
        }


        // this will submit the test and save it 
        // and close the test screen
        private void BtnSubmit_Click(object sender, RoutedEventArgs e)
        {
            this.studentScreen.setAnswerSheet(this.answerSheet);
            this.studentScreen.pushMemorandum();
            this.Close();
        }
        //this will cancel the test
        private void BtnBack_Click(object sender, RoutedEventArgs e)
        {
            studentScreen.Show();
            this.Close();
        }
    }
}
