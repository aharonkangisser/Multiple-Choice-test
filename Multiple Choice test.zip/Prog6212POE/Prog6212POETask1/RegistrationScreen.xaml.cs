﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using User;
using Test;
using Question;
using Answer;
using AnswerSheet;
namespace Prog6212POETask1
{
    /// <summary>
    /// Interaction logic for RegistrationScreen.xaml
    /// </summary>
    public partial class RegistrationScreen : Window
    {
        public MainWindow window;
        public RegistrationScreen()
        {
            InitializeComponent();
        }

        /*
         * this method is used for registering a new user to the system
         */
        private void BtnRegister_Click(object sender, RoutedEventArgs e)
        {
            //do validation checks

            string username = txtUsername.Text;
            string password = txtPassword.Text;
            string firstName = txtEnterFname.Text;
            string surname = txtSname.Text;
            bool isLecturer = (bool)chkLecturer.IsChecked;

            //identifies the fields not filled in
                if (String.IsNullOrEmpty(txtEnterFname.Text) || String.IsNullOrEmpty(txtSname.Text) || String.IsNullOrEmpty(txtUsername.Text) || String.IsNullOrEmpty(txtPassword.Text))
                {
                    MessageBox.Show("Please fill in the fields");
                    if (String.IsNullOrEmpty(txtEnterFname.Text))
                    {
                        lblEnterName.Foreground = Brushes.Red;
                    }
                    if (String.IsNullOrEmpty(txtSname.Text))
                    {
                        lblEnterSurname.Foreground = Brushes.Red;
                    }
                    if (String.IsNullOrEmpty(txtUsername.Text))
                    {
                        lblUsername.Foreground = Brushes.Red;
                    }
                    if (String.IsNullOrEmpty(txtPassword.Text))
                    {
                        lblPassword.Foreground = Brushes.Red;
                    }
                }
                else
                {



                    //dynamic abstraction and polymorphism constructors
                    User.User user = null;
                    if (isLecturer)
                    {
                        user = new Lecturer(firstName, surname, username, password);
                    }
                    else
                    {
                        user = new Student(firstName, surname, username, password);
                    }

                    window.Users.Add(user);
                    window.Show();
                    this.Close();
                }
            }
    
        //simple method to cancel and takes the user back to the login screen
        private void BtnRegisterCancel_Click(object sender, RoutedEventArgs e)
        {
           
            window.Show();
            this.Close();
        }
    }
}
