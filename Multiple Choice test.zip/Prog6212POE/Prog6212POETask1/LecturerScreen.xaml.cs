﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using User;
using Test;
using Question;
using Answer;
using AnswerSheet;
namespace Prog6212POETask1
{
    /// <summary>
    /// Interaction logic for Screen2.xaml
    /// </summary>
    public partial class Screen2 : Window
    {
        public MainWindow window;
        public Lecturer user;
        public int countTests = 0;
        public Screen2()
        {
            InitializeComponent();

        }
        /*
         * this method sign the lecturer out and takes them back to the login screen
         */
        private void BtnSignOut_Click(object sender, RoutedEventArgs e)
        {
            window.Show();
            this.Close();
        }

        /*
         * this method opens the create test window and hides the lecturer home screen
         */
        private void BtnCreateTest_Click(object sender, RoutedEventArgs e)
        {
            CreateTestScreen testScreen = new CreateTestScreen();
            testScreen.window = this;
            testScreen.Show();
            this.Hide();
        }


        /*
         * this method checks and populates the listbox with the test that that lecturer has created
         */
        private void Window_IsVisibleChanged(object sender, DependencyPropertyChangedEventArgs e)
        {
            if (this.IsVisible)
            {
                List<Test.Test> tests = user.GetTests();
                lstViewTest.Items.Clear();
                foreach (Test.Test test in tests)
                {
                    lstViewTest.Items.Add(test.getTestName());
                }

            }
        }
        /*
         * this method checks and populates the listbox with the test that that lecturer has created
         */
        private void Window_Activated(object sender, EventArgs e)
        {
                List<Test.Test> tests = user.GetTests();
                lstViewTest.Items.Clear();
                foreach (Test.Test test in tests)
                {
                    lstViewTest.Items.Add(test.getTestName());
                }
        }
        /*
         * this method checks and populates the listbox with the test that that lecturer has created
         */
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
                List<Test.Test> tests = user.GetTests();
                lstViewTest.Items.Clear();
                foreach (Test.Test test in tests)
                {
                    lstViewTest.Items.Add(test.getTestName());
                }
        }
        /*
         * this method opens the next screen being the class list and closes the lecturer home screen
         */
        private void BtnViewClassList_Click(object sender, RoutedEventArgs e)
        {
            ClassList classList = new ClassList();
            classList.window = window;
            classList.LecturerScreen = this;
            classList.Show();
            this.Hide();
        }
    }
}
