﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Microsoft.VisualBasic;
using User;
using Test;
using Question;
using Answer;
using AnswerSheet;
namespace Prog6212POETask1
{
    /// <summary>
    /// Interaction logic for CreateTestScreen.xaml
    /// </summary>
    public partial class CreateTestScreen : Window
    {
        public Screen2 window;
        private List<Question.Question> questions = new List<Question.Question>();
        Test.Test test = new Test.Test();
        public CreateTestScreen()
        {
            InitializeComponent();
        }


        /*
         * the following method is used to add a question to the test 
         * the way it works is that it pops open a screen where you enter the correct answer and the incorrect answer 
         * the amount of options for the multiple choice test 
         * eg. A,B,C or A,B,C,D or A,B,C,D,E the lecturer can have a maximum of 5 options for the multiple choie test
         */
        private void BtnAddQuestion_Click(object sender, RoutedEventArgs e)
        {
            Question.Question question = new Question.Question(questions.Count + 1,txtActualQuestion.Text);
            string answer = Interaction.InputBox("Please enter the correct answer", "Answer");
            char answerID = 'A';
            Answer.Answer currentAnswer = new Answer.Answer(answerID, answer);
            
            question.addAnswer(currentAnswer);
            question.setCorrectAnswer(answerID);

            answerID += (char)1;

            int answerAmount = (int)sldAnswerAmount.Value;
            for (int i = 0; i < answerAmount -1; i++)
            {
                answer = Interaction.InputBox("Please enter an incorrect answer", "Answer");
                currentAnswer = new Answer.Answer(answerID, answer);

                question.addAnswer(currentAnswer);

                answerID += (char)1;
            }

            questions.Add(question);
            lstQuestions.Items.Add("Question" + questions.Count);
        }

        /*
         * this method is used to take all the questions entered 
         * and compiles it to one test under the test name the lecturer set
         * and if the test name is entered and there are questions 
         * made it will then create the test and take you back to the lecturer screen
         */
        private void BtnCreateTest_Click(object sender, RoutedEventArgs e)
        {
            if (lstQuestions.Items.Count < 1)
            {
                MessageBox.Show("You have not added questions to the test. \n Please add questions");
            }
            else
            {
                if (String.IsNullOrEmpty(txtTestName.Text) || txtTestName.Text == test.getTestName())
                {

                    MessageBox.Show("whoah slow down \n Please enter a name");
                }
                else
                {

                    Test.Test createdTest = new Test.Test(window.user.getTestCount() + 1, txtTestName.Text, questions);
                    window.user.addTest(createdTest);
                    window.Show();
                    this.Close();
                }
            }
        }

        //simple method to cancel the test you are currently making
        private void BtnBack_Click(object sender, RoutedEventArgs e)
        {
            window.Show();
            this.Close();
        }
    }
}
