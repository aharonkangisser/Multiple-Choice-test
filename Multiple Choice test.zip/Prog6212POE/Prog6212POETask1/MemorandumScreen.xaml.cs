﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using User;
using Test;
using Question;
using Answer;
using AnswerSheet;
namespace Prog6212POETask1
{
    /// <summary>
    /// Interaction logic for MemorandumScreen.xaml
    /// </summary>
    public partial class MemorandumScreen : Window
    {
        public AnswerSheet.AnswerSheet answersheet;
        public StudentScreen window;
        public MarkSheet window_mark;
        public Boolean hasBeenPushed;
        public Boolean studentView;
        private List<Question.Question> testQuestions;
        private int currentQuestion;
        private int questionCount;

        public MemorandumScreen()
        {
            InitializeComponent();
        }

        /*
         * this method will be called and the beginning of the applications launch 
         * this will populate the listbox with the questions 
         * display the marks that user got for that test 
         * as well as provide the user will navigation control with next and previous button
         */
        public void loadTest()
        {

            lstQuestionList.Items.Clear();
            txtGrade.Text = "";
            testQuestions = new List<Question.Question>();
            int Count = 1;
            int answerCount = 0;
            int correctAnswerCount = 0;
            foreach (Question.Question question in answersheet.GetQuestions())
            {
                testQuestions.Add(question);
                lstQuestionList.Items.Add("Question - " + Count);
                Count += 1;

                char answerGiven = answersheet.getAnswer(answerCount);
                char answerCorrect = question.getCorrectAnswer();
                if (answerGiven == answerCorrect)
                {
                    correctAnswerCount += 1;
                }
                answerCount += 1;
            }
            currentQuestion = 0;
            questionCount = testQuestions.Count;
            setQuestionFocus(currentQuestion);
            btnPrevious.Visibility = Visibility.Hidden;

            //Add marks
            if (!hasBeenPushed)
            {
                answersheet.setActualMarks(correctAnswerCount);
                answersheet.setTotalMarks(answerCount);
            }

            txtGrade.Text = "Total Marks: " + correctAnswerCount + " / " + answerCount + "\n";
            // txtGrade.Text += "Correct Answers :" + correctAnswerCount + "\n";
            txtGrade.Text += "Percentage: " + Math.Round((((float)correctAnswerCount / (float)answerCount) * 100), 2) + "%" + "\n";
        }


        /*
         * this method is used when navigating the memorandum between each question (setting the focus)
         * the way this works is with the switch statement it will show or hide the radio buttons that match the ammount of options 
         * this (in another switch statement) will also show what the user set as there choice and whether they were correct or wrong 
         * by the indication of the text colour green = correct red = wrong 
         * if the user is wrong it will show them the correct option with the green text
         */
        private void setQuestionFocus(int focusQuestionIndex)
        {
            Question.Question focusQuestion = testQuestions[focusQuestionIndex];
            List<Answer.Answer> questionAnswers = focusQuestion.getshuffledAnswers();
            txtQuestion.Text = focusQuestion.getActualQuestion();
            int answerCount = questionAnswers.Count;
            questionCount = testQuestions.Count(); ;
            lstQuestionList.SelectedIndex = focusQuestionIndex;
            switch (answerCount)
            {
                case 1:
                    //Enable active answers
                    lblOptionA.Visibility = Visibility.Visible;
                    rdoOptionA.Visibility = Visibility.Visible;
                    rdoOptionA.IsChecked = false;
                    txtOptionA.Visibility = Visibility.Visible;
                    txtOptionA.Text = questionAnswers[0].getAnswer();
                    //Disable inactive answers

                    lblOptionB.Visibility = Visibility.Hidden;
                    rdoOptionB.Visibility = Visibility.Hidden;
                    rdoOptionB.IsChecked = false;
                    txtOptionB.Visibility = Visibility.Hidden;

                    lblOptionC.Visibility = Visibility.Hidden;
                    rdoOptionC.Visibility = Visibility.Hidden;
                    rdoOptionC.IsChecked = false;
                    txtOptionC.Visibility = Visibility.Hidden;

                    lblOptionD.Visibility = Visibility.Hidden;
                    rdoOptionD.Visibility = Visibility.Hidden;
                    rdoOptionD.IsChecked = false;
                    txtOptionD.Visibility = Visibility.Hidden;

                    lblOptionE.Visibility = Visibility.Hidden;
                    rdoOptionE.Visibility = Visibility.Hidden;
                    rdoOptionE.IsChecked = false;
                    txtOptionE.Visibility = Visibility.Hidden;

                    break;
                case 2:
                    //Enable active answers
                    lblOptionA.Visibility = Visibility.Visible;
                    rdoOptionA.Visibility = Visibility.Visible;
                    rdoOptionA.IsChecked = false;
                    txtOptionA.Visibility = Visibility.Visible;
                    txtOptionA.Text = questionAnswers[0].getAnswer();


                    lblOptionB.Visibility = Visibility.Visible;
                    rdoOptionB.Visibility = Visibility.Visible;
                    rdoOptionB.IsChecked = false;
                    txtOptionB.Visibility = Visibility.Visible;
                    txtOptionB.Text = questionAnswers[1].getAnswer();
                    //Disable inactive answers


                    lblOptionC.Visibility = Visibility.Hidden;
                    rdoOptionC.Visibility = Visibility.Hidden;
                    rdoOptionC.IsChecked = false;
                    txtOptionC.Visibility = Visibility.Hidden;

                    lblOptionD.Visibility = Visibility.Hidden;
                    rdoOptionD.Visibility = Visibility.Hidden;
                    rdoOptionD.IsChecked = false;
                    txtOptionD.Visibility = Visibility.Hidden;

                    lblOptionE.Visibility = Visibility.Hidden;
                    rdoOptionE.Visibility = Visibility.Hidden;
                    rdoOptionE.IsChecked = false;
                    txtOptionE.Visibility = Visibility.Hidden;
                    break;
                case 3:
                    //Enable active answers
                    lblOptionA.Visibility = Visibility.Visible;
                    rdoOptionA.Visibility = Visibility.Visible;
                    rdoOptionA.IsChecked = false;
                    txtOptionA.Visibility = Visibility.Visible;
                    txtOptionA.Text = questionAnswers[0].getAnswer();


                    lblOptionB.Visibility = Visibility.Visible;
                    rdoOptionB.Visibility = Visibility.Visible;
                    rdoOptionB.IsChecked = false;
                    txtOptionB.Visibility = Visibility.Visible;
                    txtOptionB.Text = questionAnswers[1].getAnswer();

                    lblOptionC.Visibility = Visibility.Visible;
                    rdoOptionC.Visibility = Visibility.Visible;
                    rdoOptionC.IsChecked = false;
                    txtOptionC.Visibility = Visibility.Visible;
                    txtOptionC.Text = questionAnswers[2].getAnswer();
                    //Disable inactive answers




                    lblOptionD.Visibility = Visibility.Hidden;
                    rdoOptionD.Visibility = Visibility.Hidden;
                    rdoOptionD.IsChecked = false;
                    txtOptionD.Visibility = Visibility.Hidden;

                    lblOptionE.Visibility = Visibility.Hidden;
                    rdoOptionE.Visibility = Visibility.Hidden;
                    rdoOptionE.IsChecked = false;
                    txtOptionE.Visibility = Visibility.Hidden;
                    break;
                case 4:
                    //Enable active answers
                    lblOptionA.Visibility = Visibility.Visible;
                    rdoOptionA.Visibility = Visibility.Visible;
                    rdoOptionA.IsChecked = false;
                    txtOptionA.Visibility = Visibility.Visible;
                    txtOptionA.Text = questionAnswers[0].getAnswer();


                    lblOptionB.Visibility = Visibility.Visible;
                    rdoOptionB.Visibility = Visibility.Visible;
                    rdoOptionB.IsChecked = false;
                    txtOptionB.Visibility = Visibility.Visible;
                    txtOptionB.Text = questionAnswers[1].getAnswer();

                    lblOptionC.Visibility = Visibility.Visible;
                    rdoOptionC.Visibility = Visibility.Visible;
                    rdoOptionC.IsChecked = false;
                    txtOptionC.Visibility = Visibility.Visible;
                    txtOptionC.Text = questionAnswers[2].getAnswer();

                    lblOptionD.Visibility = Visibility.Visible;
                    rdoOptionD.Visibility = Visibility.Visible;
                    rdoOptionD.IsChecked = false;
                    txtOptionD.Visibility = Visibility.Visible;
                    txtOptionD.Text = questionAnswers[3].getAnswer();
                    //Disable inactive answers

                    lblOptionE.Visibility = Visibility.Hidden;
                    rdoOptionE.Visibility = Visibility.Hidden;
                    rdoOptionE.IsChecked = false;
                    txtOptionE.Visibility = Visibility.Hidden;
                    break;
                case 5:
                    //Enable active answers
                    lblOptionA.Visibility = Visibility.Visible;
                    rdoOptionA.Visibility = Visibility.Visible;
                    rdoOptionA.IsChecked = false;
                    txtOptionA.Visibility = Visibility.Visible;
                    txtOptionA.Text = questionAnswers[0].getAnswer();


                    lblOptionB.Visibility = Visibility.Visible;
                    rdoOptionB.Visibility = Visibility.Visible;
                    rdoOptionB.IsChecked = false;
                    txtOptionB.Visibility = Visibility.Visible;
                    txtOptionB.Text = questionAnswers[1].getAnswer();

                    lblOptionC.Visibility = Visibility.Visible;
                    rdoOptionC.Visibility = Visibility.Visible;
                    rdoOptionC.IsChecked = false;
                    txtOptionC.Visibility = Visibility.Visible;
                    txtOptionC.Text = questionAnswers[2].getAnswer();

                    lblOptionD.Visibility = Visibility.Visible;
                    rdoOptionD.Visibility = Visibility.Visible;
                    rdoOptionD.IsChecked = false;
                    txtOptionD.Visibility = Visibility.Visible;
                    txtOptionD.Text = questionAnswers[3].getAnswer();

                    lblOptionE.Visibility = Visibility.Visible;
                    rdoOptionE.Visibility = Visibility.Visible;
                    rdoOptionE.IsChecked = false;
                    txtOptionE.Visibility = Visibility.Visible;
                    txtOptionE.Text = questionAnswers[4].getAnswer();

                    break;
            }

            char chosenOption = answersheet.getAnswer(focusQuestionIndex);
            txtOptionA.Foreground = Brushes.Black;
            txtOptionB.Foreground = Brushes.Black;
            txtOptionC.Foreground = Brushes.Black;
            txtOptionD.Foreground = Brushes.Black;
            txtOptionE.Foreground = Brushes.Black;

            switch (chosenOption)
            {
                case 'A':
                    txtOptionA.Foreground = Brushes.Red;
                    txtOptionA.Text += "\t - Your Choice";
                    break;
                case 'B':
                    txtOptionB.Foreground = Brushes.Red;
                    txtOptionB.Text += "\t - Your Choice";
                    break;
                case 'C':
                    txtOptionC.Foreground = Brushes.Red;
                    txtOptionC.Text += "\t - Your Choice";
                    break;
                case 'D':
                    txtOptionD.Foreground = Brushes.Red;
                    txtOptionD.Text += "\t - Your Choice";
                    break;
                case 'E':
                    txtOptionE.Foreground = Brushes.Red;
                    txtOptionE.Text += "\t - Your Choice";
                    break;

            }

            char correctOption = focusQuestion.getCorrectAnswer();
            switch (correctOption)
            {
                case 'A':
                    txtOptionA.Foreground = Brushes.Green;
                    // txtOptionA.Text += "\t - Your Choice";
                    break;
                case 'B':
                    txtOptionB.Foreground = Brushes.Green;
                    //  txtOptionB.Text += "\t - Your Choice";
                    break;
                case 'C':
                    txtOptionC.Foreground = Brushes.Green;
                    // txtOptionC.Text += "\t - Your Choice";
                    break;
                case 'D':
                    txtOptionD.Foreground = Brushes.Green;
                    //  txtOptionD.Text += "\t - Your Choice";
                    break;
                case 'E':
                    txtOptionE.Foreground = Brushes.Green;
                    //  txtOptionE.Text += "\t - Your Choice";
                    break;

            }
        }

        // this will push the memorandum adding the test attempt if it has not been pushed before 
        private void BtnOKAY_Click(object sender, RoutedEventArgs e)
        {
            if (!hasBeenPushed)
            {
                window.user.addTestAttempt(answersheet);
                window.Show();
            }
            else
            {
                if (studentView)
                {
                    window.Show();
                }
                else
                {
                    window_mark.Show();
                }
            }

            this.Close();
        }

        private void BtnNext_Click(object sender, RoutedEventArgs e)
        {

        }

        /*
         * navigation control between each question
         */
        private void BtnPrevious_Click(object sender, RoutedEventArgs e)
        {
            currentQuestion--;
            setQuestionFocus(currentQuestion);
            if (currentQuestion == 0)
            {
                btnPrevious.Visibility = Visibility.Hidden;
            }
            btnNext.Visibility = Visibility.Visible;
        }
        /*
         * navigation control between each question
         */
        private void BtnNext_Click_1(object sender, RoutedEventArgs e)
        {
            currentQuestion++;
            setQuestionFocus(currentQuestion);
            if (currentQuestion == (questionCount - 1))
            {
                btnNext.Visibility = Visibility.Hidden;
            }
            btnPrevious.Visibility = Visibility.Visible;
        }
    }
}
