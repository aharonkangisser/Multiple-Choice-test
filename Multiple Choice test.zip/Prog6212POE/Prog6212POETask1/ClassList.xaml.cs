﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using User;
using Test;
using Question;
using Answer;
using AnswerSheet;
using Microsoft.WindowsAPICodePack.Dialogs;


namespace Prog6212POETask1
{
    /// <summary>
    /// Interaction logic for ClassList.xaml
    /// </summary>
    public partial class ClassList : Window
    {

        //making the following variables public to allow access throughout document
        //making variables private so no other sections can access these variable
        public MainWindow window;
        public Screen2 LecturerScreen;
        private List<User.Student> students;
        private List<Test.Test> tests;
        private List<int> Marks;
        public ClassList()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            /*
             * the following code takes place in the load methods which means when the WPF window opens the line below will occur
             * 
             * the following codes performs the functions of displaying the students registered and the tests that 
             * they've taken and the marks (if complete) they got for the specified test 
             */
            students = new List<Student>();
            tests = new List<Test.Test>();
            foreach (User.User user in window.Users)
            {
                if (user.getUserRole() == 0)
                {
                    Student student = (Student)user;
                    students.Add(student);
                    lstListStudent.Items.Add(student.getStudentID() + " - " + student.getFirstName() + " " + student.getSurname());
                }
                else
                {
                    Lecturer lecturer = (Lecturer)user;
                    foreach (Test.Test test in lecturer.GetTests())
                    {
                        tests.Add(test);
                        lstListTest.Items.Add(test.getTestName());
                    }
                }
            }



        }

        private void BtnClose_Click(object sender, RoutedEventArgs e)
        {
            //simple method that closes the window
            LecturerScreen.Show();
            this.Close();
        }

        /*
         * the following method is an action listener when the item on the listbox is selected 
         * the following code will populate the text block with information of the students name marks and test attempt 
         */
        private void LstListStudent_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            Marks = new List<int>();

            int selection = lstListStudent.SelectedIndex;
            if (selection == -1)
            {
                return;
            }

            Student student = students[selection];
            txtShowTestMarks.Text = "";
            txtShowTestMarks.Text = txtShowTestMarks.Text + "Test Name \tAttempt \tMark \t%\n";
            txtShowTestMarks.Text = txtShowTestMarks.Text + "--------------------------------------------\n";
            for (int i = 0; i < student.AnswerSheetCount(); i++)
            {
                AnswerSheet.AnswerSheet tempSheet = student.GetAnswerSheet(i);
                Marks.Add(tempSheet.getActualMarks());
                txtShowTestMarks.Text = txtShowTestMarks.Text + tempSheet.getTestName() + "\t\t" + tempSheet.getTestAttempt() + "\t" + tempSheet.getActualMarks() + "/" + tempSheet.getTotalMarks() + "\t" + (Math.Round(((float)tempSheet.getActualMarks() / (float)tempSheet.getTotalMarks() * 100), 2)) + "%\n";
                //tempSheet.getActualMarks();
                // tempSheet.getTotalMarks();
                // tempSheet.getTestName();

            }
            lstListTest.SelectedIndex = -1;
        }


        /*
         * the following method is an action listener when the item on the listbox is selected 
         * the following code will populate the text block with information of the test selected by showing the students name marks and test attempt 
         */
        private void LstListTest_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            Marks = new List<int>();

            int selection = lstListTest.SelectedIndex;
            if (selection == -1)
            {
                return;
            }

            Test.Test test = tests[selection];
            txtShowTestMarks.Text = "";
            txtShowTestMarks.Text = txtShowTestMarks.Text + "ID \tStudent \t\tAttempt \tMark \t%\n";
            txtShowTestMarks.Text = txtShowTestMarks.Text + "----------------------------------------------------\n";
            foreach (Student student in students)
            {
                Boolean gotAttempt = false;
                for (int i = 0; i < student.AnswerSheetCount(); i++)
                {
                    AnswerSheet.AnswerSheet tempSheet = student.GetAnswerSheet(i);
                    if (tempSheet.getTestName() == test.getTestName())
                    {
                        gotAttempt = true;
                        Marks.Add(tempSheet.getActualMarks());
                        txtShowTestMarks.Text = txtShowTestMarks.Text + student.getStudentID() + "\t" + student.getFirstName() + " " + student.getSurname() + "\t" + tempSheet.getTestAttempt() + "\t" + tempSheet.getActualMarks() + "/" + tempSheet.getTotalMarks() + "\t" + (Math.Round(((float)tempSheet.getActualMarks() / (float)tempSheet.getTotalMarks() * 100), 2)) + "%\n";
                    }
                }

                if (!gotAttempt)
                {
                    txtShowTestMarks.Text = txtShowTestMarks.Text + student.getStudentID() + "\t" + student.getFirstName() + " " + student.getSurname() + "\t Test not attempted\n";
                }
            }
            lstListStudent.SelectedIndex = -1;
        }

        private void LstListTest_MouseDown(object sender, MouseButtonEventArgs e)
        {

        }

        private void LstListTest_MouseEnter(object sender, MouseEventArgs e)
        {

        }


        //this method is used if the lecturer wanted to export the marks to print out thos allows the lecturer to do so
        private void BtnExport_Click(object sender, RoutedEventArgs e)
        {
            CommonSaveFileDialog dialog = new CommonSaveFileDialog();
            if (dialog.ShowDialog() == CommonFileDialogResult.Ok)
            {
                System.IO.File.WriteAllText(dialog.FileName + ".txt", txtShowTestMarks.Text);
            }

        }
    }
}
